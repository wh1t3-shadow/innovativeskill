@include('pages/frontend/header')
<!------------------------- Privacy Title Section ---------------------->
<section class="auth__title_section">
    <div class="container">
        <div class="auth_title">
            <!-- Animations -->
            <div class="auth_stra_animate">
                <img src="img/background/shape8.6bd6914d.svg" alt="">
            </div>
            <!-- General Cpntent -->
            <div class="auth_title_home">
                <p><a class="auth_home" href="index.html">Home</a>/  privacy policy</p>
            </div>
            <div class="auth_title_content">
                <h3 class="sub_title">privacy policy</h3>
            </div>
        </div>
    </div>
</section>
<!------------------- privacy policy Body ----------------------->
<section class="privacy-policy">
    <div class="container">
        <h3>Privacy Policy</h3>
    </div>   
</section>

 <!------------------------- Footer Section --------------------------------->
   @include('pages/frontend/footer')